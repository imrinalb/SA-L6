package com.example.shippingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShippingApplicationTests {

    @Test
    void contextLoads() {
    }

}
