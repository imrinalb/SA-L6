package com.example.enterpriseservicebus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnterpriseServiceBusApplicationTests {

    @Test
    void contextLoads() {
    }

}
