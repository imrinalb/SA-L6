package com.example.enterpriseservicebus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.messaging.Message;
//import org.springframework.messaging.MessageChannel;
//import org.springframework.messaging.support.MessageBuilder;

//@RestController
//public class OrderController {
//    @Autowired
//    @Qualifier("wharehousechannel")
//    MessageChannel warehouseChannel;
//
//    @PostMapping("/orders")
//    public ResponseEntity<?> receiveOrder(@RequestBody Order order) {
//        Message<Order> orderMessage = MessageBuilder.withPayload(order).build();
//        warehouseChannel.send(orderMessage);
//        return new ResponseEntity<Order>(order, HttpStatus.OK);
//    }
//}

@RestController
public class OrderController {

    private final MessageChannel warehouseChannel;

    public OrderController(@Qualifier("wharehousechannel") MessageChannel warehouseChannel) {
        this.warehouseChannel = warehouseChannel;
    }

    @PostMapping("/orders")
    public ResponseEntity<Order> receiveOrder(@RequestBody Order order) {
        Message<Order> orderMessage = MessageBuilder.withPayload(order).build();
        warehouseChannel.send(orderMessage);
        return new ResponseEntity<>(order, HttpStatus.OK);
    }
}